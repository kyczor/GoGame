package models.msgs;

public class Ack {

}
