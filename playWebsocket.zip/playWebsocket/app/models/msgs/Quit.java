package models.msgs;

public class Quit {	
	     
        final String name;
        
        public String getName() {
			return name;
		}

		public Quit(String name) {
            this.name = name;
        }

}
