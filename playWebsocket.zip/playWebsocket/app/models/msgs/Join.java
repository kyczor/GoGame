package models.msgs;

public class Join {

    final String username;
    
    public String getUsername() {
		return username;
	}
   
    public Join(String username) {
        this.username = username;
    }
}
